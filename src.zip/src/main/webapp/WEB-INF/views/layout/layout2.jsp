<%@ page language="java" contentType="text/html; charset=EUC-KR" pageEncoding="EUC-KR"%>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions"%>
<%@ taglib prefix="tiles" uri="http://tiles.apache.org/tags-tiles"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>NodeFarm MES</title>
<style>
    * { 
        box-sizing: border-box; 
        margin: 0; 
        padding: 0; 
    }
    body { 
        font-family: 'Malgun Gothic', sans-serif; 
        background-color: #F8F9FA; 
    }
    /* ȭ�� ��ü�� flex �����̳ʷ� ����� ���߾� ���� */
    .mat-all { 
        display: flex; 
        justify-content: center; 
        align-items: center; 
        min-height: 100vh; 
        width: 100vw;
    }
    /* ���� ���� ����ȭ */
    .cont { 
        width: 100%;
        max-width: 500px; /* �α��� �ڽ��� �ʹ� ������ �ʵ��� �ִ� �ʺ� ���� */
        padding: 2rem; 
    }
</style>
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/page.css">
</head>
<body>

<div class="mat-all">
    <main class="cont">
        <tiles:insertAttribute name="content" />
    </main>
</div>

</body>
</html>